## Penugasan GMRT

1. Kelompokkan Data menjadi 3 bagian Merah,Biru,dan Hijau Terserah mau menggunakan metode apa tapi kalian harus bisa menjelaskan kenapa memilih metode seperti itu

2. Buat essay singkat terkait algoritma yang akan digunakan pada bagian Tic Tac Toe pada Perlombaan nanti

## Cp
Jika ada yang ingin ditanyakan bisa via Wa atau Discord

[Link Wa](https://wa.me/6281365787728)
